# نظام المصادقة - وظائف عُمان

## 📋 نظرة عامة

تم بناء نظام تسجيل الدخول باستخدام **Supabase Auth** الحقيقي مع تخزين إضافي في **KV Store** للملفات الشخصية.

---

## 🔐 كيفية عمل النظام

### 1. **تسجيل مستخدم جديد (Sign Up)**

**المسار:** `/register`

**ما يحدث خلف الكواليس:**
1. المستخدم يدخل: الاسم، البريد الإلكتروني، كلمة المرور
2. يتم إرسال البيانات إلى: `/make-server-8a20c00b/signup`
3. Server يقوم بـ:
   - ✅ إنشاء المستخدم في **Supabase Auth** (جدول `auth.users`)
   - ✅ تأكيد البريد الإلكتروني تلقائياً
   - ✅ حفظ profile إضافي في **KV Store** بمفتاح `user_profile:{userId}`
4. تسجيل دخول تلقائي للمستخدم

**البيانات المخزنة:**
```json
// في Supabase Auth (auth.users)
{
  "id": "uuid",
  "email": "user@example.com",
  "user_metadata": {
    "name": "اسم المستخدم"
  }
}

// في KV Store (user_profile:uuid)
{
  "id": "uuid",
  "email": "user@example.com",
  "name": "اسم المستخدم",
  "createdAt": "2025-11-08T...",
  "role": "user"
}
```

---

### 2. **تسجيل الدخول (Login)**

**المسار:** `/login`

**ما يحدث:**
1. المستخدم يدخل: البريد، كلمة المرور
2. يتم المصادقة مباشرة مع **Supabase Auth** من Frontend
3. عند النجاح:
   - ✅ حفظ `access_token` في localStorage
   - ✅ حفظ بيانات المستخدم في localStorage
   - ✅ التوجه للصفحة الرئيسية

---

### 3. **عرض حالة المستخدم في Header**

- إذا كان المستخدم مسجل دخول: يظهر اسمه + زر تسجيل خروج
- إذا لم يكن مسجل: يظهر "تسجيل الدخول" + "إنشاء حساب"

---

## 🗄️ قاعدة البيانات

### ✅ ما هو موجود:

1. **Supabase Auth (مدمج):**
   - جدول `auth.users` - يُدار تلقائياً بواسطة Supabase
   - لا يحتاج أي setup إضافي

2. **KV Store Table (`kv_store_8a20c00b`):**
   - متاحة بالفعل
   - تُستخدم لتخزين:
     - `user_profile:{userId}` - معلومات المستخدمين الإضافية
     - `job:{jobId}` - الوظائف
     - `admin:user` - بيانات المدير

---

## 🔧 API Endpoints

### للمستخدمين:

| Endpoint | Method | الوصف |
|----------|--------|-------|
| `/make-server-8a20c00b/signup` | POST | تسجيل مستخدم جديد |
| `/make-server-8a20c00b/user/profile/:userId` | GET | جلب profile المستخدم |

### للمديرين:

| Endpoint | Method | الوصف |
|----------|--------|-------|
| `/make-server-8a20c00b/admin/users` | GET | جلب جميع المستخدمين |
| `/make-server-8a20c00b/admin/login` | POST | تسجيل دخول المدير |
| `/make-server-8a20c00b/admin/register` | POST | تسجيل أول مدير |

---

## ⚠️ هام: خطوات التشغيل

### إذا كانت المشكلة "404 Not Found":

1. **تأكد من deploy الـ Edge Function:**
   - اذهب إلى: [Supabase Dashboard](https://supabase.com/dashboard)
   - افتح مشروعك: `jvfaelfsmpigdeiypuic`
   - Edge Functions → تحقق من وجود `make-server-8a20c00b`
   - إذا لم تكن موجودة، deploy الـ `/supabase/functions/server/` folder

2. **تحقق من Console في المتصفح (F12):**
   - شاهد رسائل الخطأ
   - تحقق من الـ Network tab

3. **تحقق من Environment Variables:**
   - `SUPABASE_URL` ✅
   - `SUPABASE_SERVICE_ROLE_KEY` ✅
   - `SUPABASE_ANON_KEY` ✅

---

## 🎯 الخلاصة

- ✅ النظام يستخدم **بيانات حقيقية** (Supabase Auth + KV Store)
- ✅ **لا حاجة لإنشاء جداول جديدة** - كل شيء جاهز
- ✅ المستخدمون يُخزنون في `auth.users` تلقائياً
- ✅ Profiles إضافية في KV Store
- ⚠️ تأكد من أن Edge Function deployed

---

## 📞 إذا استمرت المشكلة

افتح Console (F12) وأخبرني بالرسالة بالضبط!
