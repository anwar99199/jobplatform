
  # منصة الوظائف

  This is a code bundle for منصة الوظائف. The original project is available at https://www.figma.com/design/F1lhG3fEpQh9HiIAr03D6M/%D9%85%D9%86%D8%B5%D8%A9-%D8%A7%D9%84%D9%88%D8%B8%D8%A7%D8%A6%D9%81.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  